package resources;

import java.util.ArrayList;
import java.util.List;

import pojo.CreateBitlink;

public class TestDataBuild {

	public CreateBitlink CreateBitLinkPayload(String long_url, String domain, String group_guid, String title){
		
		CreateBitlink c = new CreateBitlink();
		c.setLong_url(long_url);
		c.setDomain(domain);
		c.setGroup_guid(group_guid);
		c.setTitle(title);
		List<String> mylist = new ArrayList<String>();
		mylist.add("API");
		mylist.add("QE");
		mylist.add("automation");
		c.setTags(mylist);
		
		return c;
		
	}
}
