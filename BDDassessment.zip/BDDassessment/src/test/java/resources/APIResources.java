package resources;

public enum APIResources {

	CreateBitLinkAPI("/v4/bitlinks"),
	RetrieveGroupsAPI("/v4/groups"),
	sortedBitlinkGroupAPI("/v4/groups/Bm5de3bKYlV/bitlinks/clicks");
	private String resource;
	APIResources(String resource){
		this.resource=resource;
		
	}
	
	public String getResource(){
		return resource;
	}
}
