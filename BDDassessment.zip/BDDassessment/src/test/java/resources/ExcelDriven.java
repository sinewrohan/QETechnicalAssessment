package resources;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;

public class ExcelDriven {

	@Test
	public void addBook() throws IOException {
		DataDriven d = new DataDriven();

		ArrayList data = d.getData("CreateBitlink", "testdata");

		HashMap<String, Object> map = new HashMap<>();
		map.put("long_url", data.get(1));
		map.put("domain", data.get(2));
		map.put("group_guid", data.get(3));
		map.put("title", data.get(4));

		RestAssured.baseURI = "https://api-ssl.bitly.com";

		String response = given().header("Content-Type", "application/json")
				.header("Authorization", "Bearer " + "f67ceda1fa438012b2552cb29b5aca7224bd9b20").body(map).when()
				.post("/v4/bitlinks").then().assertThat().statusCode(200).extract().response().asString();

		System.out.println(response);

		// Create a place =response (place id)

		// delete Place = (Request - Place id)

	}

	public static String GenerateStringFromResource(String path) throws IOException {

		return new String(Files.readAllBytes(Paths.get(path)));

	}
}
