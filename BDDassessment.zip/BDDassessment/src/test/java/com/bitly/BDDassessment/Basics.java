package com.bitly.BDDassessment;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import files.ReusableMethods;

public class Basics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Retrive Groups in bitly.com

		RestAssured.baseURI = "https://api-ssl.bitly.com";
		String response = given().log().all().header("Content-Type", "application/json")
				.header("Authorization", "Bearer " + "f67ceda1fa438012b2552cb29b5aca7224bd9b20")
				.relaxedHTTPSValidation().when().get("/v4/groups/").then().log().all().assertThat().statusCode(200)
				.header("Server", "nginx").extract().response().asString();
		
	
		JsonPath js1=ReusableMethods.rawToJson(response);
		String groupId = js1.getString("groups[0].guid");
		String orgId = js1.get("groups[0].organization_guid");
		System.out.println(groupId);
		System.out.println(orgId);

		
		//Shorten the url - POST CALL
		
	String shorturl=	given().log().all().header("Content-Type", "application/json").header("Authorization", "Bearer " + "f67ceda1fa438012b2552cb29b5aca7224bd9b20")
		.relaxedHTTPSValidation().body("{\r\n" + 
				"    \"long_url\": \"http://www.testinglexis1.com/\",\r\n" + 
				"    \"domain\": \"bit.ly\",\r\n" + 
				"    \"group_guid\": \""+groupId+"\",\r\n" + 
				"    \"title\": \"Assessment\",\r\n" + 
				"    \"tags\": [\r\n" + 
				"        \"QE\",\r\n" + 
				"        \"api\"\r\n" + 
				"    ]\r\n" + 
				"}").when().post("/v4/bitlinks").then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		System.out.println(shorturl);
		
		
		//Retrieve sorted bitlinks from group
		
		String retrieveBitlinks=given().log().all().header("Content-Type", "application/json")
		.header("Authorization", "Bearer " + "f67ceda1fa438012b2552cb29b5aca7224bd9b20").queryParam("unit", "day").queryParam("units", "-1").queryParam("unit_reference", "2022-05-13T16:04:05-0700").queryParam("size", "10")
		.relaxedHTTPSValidation().when().get("/v4/groups/Bm5de3bKYlV/bitlinks/clicks").then().log().all().assertThat().statusCode(200)
		.header("Server", "nginx").extract().response().asString();
		System.out.println(retrieveBitlinks);
		
		
	}

}
