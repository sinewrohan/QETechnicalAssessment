package stepDefinations;

import static io.restassured.RestAssured.given;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.CreateBitlink;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utils;

import static org.junit.Assert.*;

public class StepDefination extends Utils {

	public ResponseSpecification resspec;
	public RequestSpecification res;
	Response response;
	TestDataBuild t = new TestDataBuild();
	

	@Given("{string}")
	public void string(String string) throws IOException {
		res = given().spec(requestSpecification());
	}
	
	
	@Then("verify guid generated maps to {string} using {string}")
	public void verify_guid_generated_maps_to_using_create_bit_link_api(String string1, String string2) {
		String group_id=getJsonPath(response, "group_id");
	}
	
	@Given("{string} payload with {string} {string} {string} {string}")
	public void payload_with(String string, String long_url, String domain, String group_guid, String title) throws IOException {

		res = given().spec(requestSpecification()).body(t.CreateBitLinkPayload(long_url,domain, group_guid, title));
	}

	@When("user calls {string} using {string} http request")
	public void user_calls_using_http_request(String resource, String method) {
		APIResources resourceAPI=	APIResources.valueOf(resource);
		
		resspec=new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		
		if(method.equalsIgnoreCase("POST"))
		response = res.when().post(resourceAPI.getResource());
		else if(method.equalsIgnoreCase("GET")){
			response = res.when().get(resourceAPI.getResource());
			
		}
		
	}

	@Then("the API call is success with status code {int}")
	public void the_api_call_is_success_with_status_code(Integer int1) {
		
		assertEquals(response.getStatusCode(), 200);
	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String keyValue, String Expectedvalue) {
		
		
		assertEquals(getJsonPath(response, keyValue), Expectedvalue);

	}

}
