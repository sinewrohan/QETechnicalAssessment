package stepDefinations;

import java.io.IOException;

import io.cucumber.java.Before;

public class Hooks {

	@Before("@CreateBitLinkAPI")
	public void beforeSCenario() throws IOException{
		
		//We will write a code that will execute CreateBitLinkAPI before retrieveGroupsAPI
		
		StepDefination s= new StepDefination();
		s.string("string");
		s.user_calls_using_http_request("CreateBitLinkAPI", "POST");
	}
}
