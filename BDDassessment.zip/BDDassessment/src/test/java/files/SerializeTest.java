package files;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.CreateBitlink;

public class SerializeTest {

	public static void main(String[] args){
	//Create BitLinks
	RestAssured.baseURI = "https://api-ssl.bitly.com";
	
	CreateBitlink c= new CreateBitlink();
	c.setLong_url("http://www.testinglexis2.com/");
	c.setDomain("bit.ly");
	c.setGroup_guid("Bm5de3bKYlV");
	c.setTitle("QE testing");
	List<String> mylist= new ArrayList<String>();
	mylist.add("API");
	mylist.add("QE");
	mylist.add("automation");
	c.setTags(mylist);
	
	
	RequestSpecification req= new RequestSpecBuilder().setBaseUri("https://api-ssl.bitly.com").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + "f67ceda1fa438012b2552cb29b5aca7224bd9b20").setRelaxedHTTPSValidation().build();
	ResponseSpecification resspec=new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();

	
	RequestSpecification res=	given().spec(req).body(c);
	
	
	Response response= res.when().post("/v4/bitlinks").then().spec(resspec).extract().response();
			
			String responseString=response.asString();
	System.out.println(responseString);
	
	
}
}
